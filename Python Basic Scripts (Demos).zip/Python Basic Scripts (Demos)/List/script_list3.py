#change and add values in the list

# mistake values
odd = [[],[]]

# change the 1st item    
odd= 1            
odd=2
# Output: [1, 4, 6, 8]
print(odd)

# change 2nd to 4th items
#odd[1:4] = [3, 5, 7]  

# Output: [1, 3, 5, 7]
#print(odd)                   
