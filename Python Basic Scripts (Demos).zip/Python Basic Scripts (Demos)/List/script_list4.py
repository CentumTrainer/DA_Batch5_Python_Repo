#change and add values in the list

odd = [1, 9, 10, 20]
odd.insert(1,3)

# Output: [1, 3, 9] 
print(odd)

odd[2:4] = [5, 7]

# Output: [1, 3, 5, 7, 9]
print(odd)
