#negative index in tuple
my_tuple = ['p','e','r','m','i','t']

# Output: 't'
print(my_tuple[-1])

# Output: 'p'
print(my_tuple[-6])