# Program to generate a random number between 0 and 9

# import the random module
import random

print(random.randint(0,9))